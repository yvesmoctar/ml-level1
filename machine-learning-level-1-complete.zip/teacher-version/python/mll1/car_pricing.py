# -*- coding: utf-8 -*-
import os
import numpy as np
import pandas as pd

from scipy.stats import t, norm
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
from sklearn.kernel_ridge import KernelRidge


import matplotlib.pyplot as plt


def open_file(path):
    """Open a single dataset file

    Open a single dataset file and add the base file name
    in the "brand" column.

    Some column name are corrected to ensure consitency.

    Parameters
    ----------
    path: str
        The path of the file to load.

    Returns
    -------
    df: pandas.DataFrame
        The loaded data frame
    """
    df = pd.read_csv(path)
    brand = os.path.splitext(os.path.basename(path))[0]
    df["brand"] = brand
    return df.rename(columns={"tax(£)": "tax"})


def load_dataset(data_dir):
    """Load the used cars dataset"""
    csv_files = [
        os.path.join(data_dir, fname)
        for fname in os.listdir(data_dir)
        if "unclean" not in fname and fname.endswith(".csv")
    ]

    return pd.concat(open_file(fname) for fname in sorted(csv_files)).reset_index(
        drop=True
    )


def normalize_string_values(df, columns):
    """Normalize string values

    Normalize string value by removing trailing and leading white spaces
    and applying a `title` transformation.

    Parameters
    ----------
    df: pandas.DataFrame
        The input dataframe

    columns: seq of str
        The columns to treat

    Returns
    -------
    df_norm: pandas.DataFrame
        The treated data frame
    """
    df_norm = df.copy()
    for c in columns:
        df_norm[c] = df[c].str.strip().str.title()
    return df_norm


def fuse_string_values(df, column, values, fused_value):
    """Fuse string values

    Replace several string values by a single value. Other values are
    remained unchanged.

    Parameters
    ----------
    df: pandas.DataFrame
        The input data frame.

    column: str
        The column to treat.

    values: seq of str
        The values to fuse.

    fused_value: str
        The value to use to replace fused values

    Returns
    -------
    df_fused: pandas.DataFrame
        The treated data frame
    """
    return df.assign(
        **{column: df[column].apply(lambda x: fused_value if x in values else x)}
    )


def replace_values(df, column, value_map):
    """Replace values

    Parameters
    ----------
    df: pandas.DataFrame
        The input data frame

    column: str
        The name of the column to treat.

    value_map: dict[str, str]
        The values to replace as (original_value, replacement_value)
        pairs.

    Returns
    -------
    df_repl: pandas.DataFrame
        The treated data frame
    """
    return df.assign(**{column: df[column].apply(lambda x: value_map.get(x, x))})


def add_quality_column(df, funcs, suffix="_quality"):
    """Add columns to assess column quality

    Columns are added to assess original column qualities. The
    new columns have the same name as the original colum with an
    added suffix. The quality assessment is done by providing functions
    for each column.

    Parameters
    ----------
    df: pandas.DataFrame
        The input data frame

    funcs: dict[str, callable]
        A dictionary with (column_name, function) pairs.

    Returns
    -------
    df_qual: pandas.DataFrame
        The data frame with additional quality columns
    """
    return df.assign(
        **{column + suffix: func(df[column]) for column, func in funcs.items()}
    )


def prepare_dataset(df):
    """Prepare the data set"""
    cat_cols = [c for c in df.columns if df.dtypes[c] == "object"]
    df = normalize_string_values(df, cat_cols)
    df = fuse_string_values(df, "fuelType", ["Other", "Electric"], "Electric + Other")
    df = replace_values(df, "brand", {"Focus": "Ford", "Cclass": "Merc"})

    quality_funcs = {
        "year": lambda x: np.where(np.in1d(x, [2060, 1970]), "ko", "ok"),
        "engineSize": lambda x: np.where(x == 0.0, "ko", "ok"),
    }

    df = add_quality_column(df, quality_funcs)
    # For MPG we need conditions on 2 variables
    df["mpg_quality"] = np.where(
        (df.mpg < 15) | ((df.mpg > 130) & (df.fuelType.isin(["Petrol", "Diesel"]))),
        "ko",
        "ok",
    )

    df["tax_mpg_missing"] = df["tax"].isnull()

    return df


def plot_pred_errors(ytrue, ypred):
    plt.figure(figsize=(12, 6))
    plt.subplot(1, 2, 1)
    plt.scatter(ytrue, ypred)
    plt.xlabel("ytrue")
    plt.ylabel("ypred")

    xmin, xmax = plt.xlim()
    ymin, ymax = plt.ylim()
    plt.plot([xmin, xmax], [xmin, xmax], c="k")
    plt.xlim(xmin, xmax)
    plt.ylim(ymin, ymax)

    plt.subplot(1, 2, 2)
    diff = ypred - ytrue
    error_mean = diff.mean()
    error_std = diff.std()

    plt.hist(ypred - ytrue, bins=100, density=True, label="data")
    xmin, xmax = plt.xlim()
    x = np.linspace(xmin, xmax, 101)
    plt.plot(x, norm.pdf(x, error_mean, error_std), label="fitted normal")
    df, mu, std = t.fit(diff)
    plt.plot(x, t.pdf(x, df, mu, std), label="fitted student")
    plt.xlim(xmin, xmax)
    plt.xlabel("Prediction error")
    plt.ylabel("Density")
    plt.legend()

    print(f"Error mean: {error_mean:g}; error std: {error_std:g}")
    print("RMSE: ", np.sqrt(mean_squared_error(ytrue, ypred)))
    print("MAE:  ", mean_absolute_error(ytrue, ypred))
    print("R²:   ", r2_score(ytrue, ypred))


def build_2d(grid_size, seed):
    rng = np.random.RandomState(seed)
    width = 1 / grid_size
    gamma = 0.5 / width**2

    r = np.linspace(0, 1, grid_size)
    xy = np.dstack(np.meshgrid(r, r)).reshape(-1, 2)
    z = rng.uniform(size=len(xy))

    reg = KernelRidge(kernel="rbf", gamma=gamma)
    reg.fit(xy, z)

    return reg.predict


def r2_score_clipped(ytrue, ypred):
    return r2_score(ytrue, ypred.clip(0, np.inf))
