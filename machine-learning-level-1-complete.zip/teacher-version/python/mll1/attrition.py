import pandas as pd


def load_dataset(datafile):
    """Load the attrition dataset

    Reads the input excel file and concatenates left and remaining
    employees in the same data frame. Applies a column name correction.

    Parameters
    ----------
    datafile: str
        The path to the input datafile
    """
    with pd.io.excel.ExcelFile(datafile) as efile:
        df_exist = pd.read_excel(efile, sheet_name="Existing employees")
        df_left = pd.read_excel(efile, sheet_name="Employees who have left")

    df_attr = pd.concat([df_exist.assign(has_left=0), df_left.assign(has_left=1)])

    return df_attr.rename(columns={"average_montly_hours": "average_monthly_hours"})
