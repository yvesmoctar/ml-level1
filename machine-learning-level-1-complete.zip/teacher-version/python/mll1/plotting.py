from copy import deepcopy
import numpy as np
import matplotlib as mpl
from matplotlib import pyplot as plt
from matplotlib.cm import get_cmap
from scipy.cluster.hierarchy import dendrogram
from sklearn import metrics
from sklearn.pipeline import Pipeline


def project_gmm(gmm, coords):
    gmm_proj = deepcopy(gmm)
    gmm_proj.means_ = gmm.means_[:, coords]
    gmm_proj.covariances_ = gmm.covariances_[:, coords][..., coords]
    gmm_proj.weights_ = gmm.weights_

    if hasattr(gmm_proj, "n_features_in_"):
        gmm_proj.n_features_in_ = len(coords)

    # Recompute precision matrices
    gmm_proj.precisions_ = np.array(
        [np.linalg.pinv(cov) for cov in gmm_proj.covariances_]
    )
    # And their cholesky decomposition too
    gmm_proj.precisions_cholesky_ = np.array(
        [np.linalg.cholesky(prec) for prec in gmm_proj.precisions_]
    )

    return gmm_proj


def plot_gmm(gmm, coords=None, color_iter=get_cmap("Set1").colors):
    if coords is not None:
        gmm = project_gmm(gmm, coords)

    means = gmm.means_
    covariances = gmm.covariances_
    weights = gmm.weights_
    alphas = np.linspace(0.1, 0.8, gmm.n_components)

    for i, (mean, covar, weight, color) in enumerate(
        zip(means, covariances, weights, color_iter)
    ):
        v, w = np.linalg.eigh(covar)
        v = 2.0 * np.sqrt(2.0) * np.sqrt(v)
        u = w[0] / np.linalg.norm(w[0])

        # Plot an ellipse to show the Gaussian component
        angle = np.arctan(u[1] / u[0])
        angle = 180.0 * angle / np.pi  # convert to degrees
        ell = mpl.patches.Ellipse(mean, v[0], v[1], angle=180.0 + angle, color=color)
        ell.set_alpha(alphas[i])
        plt.gca().add_artist(ell)
        plt.scatter([mean[0]], [mean[1]], c=[color])


def plot_correlation_circle(pca, axes, feature_names):
    """Plot correlation circle from PCA object

    Parameters
    ----------
    pca: sklearn.decomposition.PCA
        The fit PCA estimator
    axes: tuple of int
        The indexes of the 2 principal coords to plot.
    feature_names: list of str
        The list of feature names
    """
    axes = list(axes)
    components = pca.components_[axes].T * np.sqrt(pca.explained_variance_[axes])
    circle = plt.Circle((0, 0), 1.0, fill=False)
    for (x, y), name in zip(components, feature_names):
        plt.text(x, y, name)
        plt.plot([0, x], [0, y], c="lightgray")
    plt.gca().add_artist(circle)
    plt.xlim(-1, 1)
    plt.ylim(-1, 1)
    plt.xlabel(f"pc{axes[0] + 1}")
    plt.ylabel(f"pc{axes[1] + 1}")


def plot_stacked_percent_bars(
    df, column, hue="has_left", count_col="Emp ID", order=None
):
    df_pivot = df.pivot_table(
        index=column, columns=hue, values=count_col, aggfunc="count", fill_value=0
    )

    if order is not None:
        df_pivot = df_pivot.loc[order]

    df_pivot.divide(df_pivot.sum(1) / 100.0, axis="rows").reset_index().plot.barh(
        x=column, stacked=True
    )
    plt.legend(loc="upper right", bbox_to_anchor=(1.2, 1), title=hue)
    plt.xlim(0, 100)


def polar_plot(df, fill=False, normalize=True, label="cluster"):
    if normalize:
        df = (df - df.min()) / (df.max() - df.min())
    angles = list(np.linspace(0, 2 * np.pi, df.shape[1], endpoint=False))
    labels = list(df.columns)

    with plt.style.context("seaborn-v0_8-darkgrid"):
        ax = plt.gcf().add_subplot(111, polar=True)
        ax.set_thetagrids(np.array(angles) * 180 / np.pi, labels)
        ax.grid(True)
        ax.set_ylim(-0.2, 1)

        for i in df.index:
            stats = list(df.loc[i])
            ax.plot(
                angles + [angles[0]],
                stats + [stats[0]],
                "o-",
                linewidth=2,
                label=f"{label} {i}",
            )
            if fill:
                ax.fill(angles, stats, alpha=0.25)

        plt.legend(loc="upper right", bbox_to_anchor=(1.2, 1.0))


def plot_decision_function(reg, gridsize=101):
    # Compute the decision function value on a grid
    xmin, xmax = plt.xlim()
    ymin, ymax = plt.ylim()
    xx, yy = np.meshgrid(
        np.linspace(xmin, xmax, gridsize), np.linspace(ymin, ymax, gridsize)
    )
    X = np.dstack([xx, yy]).reshape(-1, 2)

    # Retrieve the decision function
    if hasattr(reg, "decision_function"):
        decision_function = reg.decision_function
        f = reg.decision_function(X)
        vmax = max(f.max(), -f.min())
        vmin = -vmax
        level = 0
    elif hasattr(reg, "predict_proba"):
        f = reg.predict_proba(X).T[1]
        vmin, vmax = 0.0, 1.0
        level = 0.5
    else:
        raise ValueError(
            "The estimator has neither `decision_function` nor `predict_proba` method."
        )

    f = f.reshape(xx.shape)

    # Plot the decision function in the plane
    plt.imshow(
        f,
        extent=[xmin, xmax, ymin, ymax],
        cmap="coolwarm_r",
        origin="lower",
        vmin=vmin,
        vmax=vmax,
    )
    plt.colorbar()

    # Plot the decision border
    plt.contour(xx, yy, f, levels=[level], colors="k")


def plot_pdf(pdf, xrange, yrange, gridsize=101, levels=None, clip_quantile=0.99):
    xmin, xmax = xrange
    ymin, ymax = yrange

    xx, yy = np.meshgrid(
        np.linspace(xmin, xmax, gridsize), np.linspace(ymin, ymax, gridsize)
    )
    X = np.dstack([xx, yy]).reshape(-1, 2)

    zz = pdf(X).reshape(xx.shape)
    zmax = np.quantile(zz, clip_quantile)
    zz = zz.clip(None, zmax)
    # Plot the decision border
    plt.contour(xx, yy, zz, levels=levels)


def plot_gmm_pdf(
    gmm, xrange, yrange, gridszie=101, levels=None, coords=None, clip_quantile=0.99
):
    if coords is not None:
        gmm = project_gmm(gmm, coords)

    gmm_pdf = lambda x: np.exp(gmm.score_samples(x))

    plot_pdf(
        gmm_pdf,
        xrange,
        yrange,
        gridsize=gridszie,
        levels=levels,
        clip_quantile=clip_quantile,
    )


def plot_dendrogram(model, **kwargs):
    # Create linkage matrix and then plot the dendrogram

    # create the counts of samples under each node
    counts = np.zeros(model.children_.shape[0])
    n_samples = len(model.labels_)
    for i, merge in enumerate(model.children_):
        current_count = 0
        for child_idx in merge:
            if child_idx < n_samples:
                current_count += 1  # leaf node
            else:
                current_count += counts[child_idx - n_samples]
        counts[i] = current_count

    linkage_matrix = np.column_stack(
        [model.children_, model.distances_, counts]
    ).astype(float)

    # Plot the corresponding dendrogram
    dendrogram(linkage_matrix, **kwargs)


def _get_model_name(model):
    if hasattr(model, "estimator"):
        model = model.estimator
    if isinstance(model, Pipeline):
        model = model.steps[-1][1]
    return model.__class__.__name__


def _get_score(clf, X, y):
    try:
        yscore = clf.predict_proba(X).T[1]
    except AttributeError:
        yscore = clf.decision_function(X)
    return yscore


def plot_precision_recall_curve(clf, X, y, name=None, **kwargs):
    if name is None:
        name = _get_model_name(clf)

    yscore = _get_score(clf, X, y)
    prec, recall, _ = metrics.precision_recall_curve(y, yscore)
    avg_prec = metrics.average_precision_score(y, yscore)
    metrics.PrecisionRecallDisplay(precision=prec, recall=recall).plot(
        name=f"AP={avg_prec:0.3g} -- {name}", **kwargs
    )


def plot_roc_curve(clf, X, y, name=None, **kwargs):
    if name is None:
        name = _get_model_name(clf)

    yscore = _get_score(clf, X, y)
    fpr, tpr, _ = metrics.roc_curve(y, yscore)
    auc = metrics.roc_auc_score(y, yscore)

    metrics.RocCurveDisplay(
        fpr=fpr,
        tpr=tpr,
    ).plot(name=f"AUC={auc:0.3g} -- {_get_model_name(clf)}", **kwargs)


def plot_classification_result(clf, X, y, name=None):
    yscore = _get_score(clf, X, y)
    print(
        f"Avg Prec: {metrics.average_precision_score(y, yscore):0.3f} (pos. ratio: {y.mean():0.3f})"
    )
    print(f"ROC AUC: {metrics.roc_auc_score(y, yscore):0.3f}")

    plt.figure(figsize=(12, 4))
    plt.subplot(1, 2, 1)
    plot_precision_recall_curve(clf, X, y, name=name, ax=plt.gca())
    plt.title("Precision / Recall")

    plt.subplot(1, 2, 2)
    plt.title("ROC")
    plot_roc_curve(clf, X, y, name=name, ax=plt.gca())
