import fastapi
import joblib
import pandas as pd
import json
import numpy as np
import pathlib


model_dir = pathlib.Path("../notebooks")
model = joblib.load(model_dir / "cars_price_model.pkl")
with open(model_dir / "config.json") as infile:
    config = json.load(infile)


app = fastapi.FastAPI()


@app.get("/price/")
def price(
    brand: str,
    car_model: str,
    engine_size: float,
    fuel_type: str,
    transmission: str,
    mileage: float,
    year: int,
):
    df = pd.DataFrame(
        [
            {
                "brand": brand,
                "model": car_model,
                "engineSize": engine_size,
                "fuelType": fuel_type,
                "transmission": transmission,
                "year": year,
                "mileage": mileage,
                "tax": np.nan,
                "mpg": np.nan,
            }
        ]
    )[config["columns"]]
    return {"price": model.predict(df)[0]}
