import os
import pathlib
import joblib
import json
import numpy as np
import pandas as pd
import streamlit as st

model_dir = pathlib.Path(os.path.dirname(__file__)) / ".." / "notebooks"


def get_all_values(feat_name, config):
    return sorted(
        list(
            set(
                sum(
                    [
                        list(model_feat[feat_name])
                        for model_feat in config["features_per_models"].values()
                    ],
                    [],
                )
            )
        )
    ) + ["Other"]


@st.cache_data
def load_model_and_config():
    reg = joblib.load(model_dir / "cars_price_model.pkl")
    with open(model_dir / "config.json") as infile:
        config = json.load(infile)
    return reg, config


reg, config = load_model_and_config()


all_sizes = get_all_values("engineSize", config)
all_fuel_types = get_all_values("fuelType", config)
all_transmissions = get_all_values("transmission", config)


col1, col2 = st.columns(2)

with col1:
    brand = st.selectbox(
        label="Brand:", options=sorted(config["model_per_brand"].keys())
    )

with col2:
    model = st.selectbox(
        label="Model:", options=sorted(config["model_per_brand"][brand]) + ["Other"]
    )

col1, col2, col3 = st.columns(3)
with col1:
    engine_size = st.selectbox(
        label="Engine Size:",
        options=all_sizes,
    )

with col2:
    fuel_type = st.selectbox(label="Fuel Type:", options=all_fuel_types)

with col3:
    transmission = st.selectbox(label="Transmission:", options=all_transmissions)

col1, col2 = st.columns(2)


with col1:
    mileage = st.number_input(
        label="Mileage", min_value=0, max_value=1000000, value=100000
    )

with col2:
    year = st.slider(label="Year:", min_value=1970, max_value=2021, value=2021)


engine_size = np.nan if engine_size == "Other" else float(engine_size)
mileage = 10000 if mileage == "" else float(mileage)

df = pd.DataFrame(
    [
        {
            "brand": brand,
            "model": model,
            "engineSize": engine_size,
            "fuelType": fuel_type,
            "transmission": transmission,
            "year": year,
            "mileage": mileage,
            "tax": np.nan,
            "mpg": np.nan,
        }
    ]
)[config["columns"]]

ypred = f"{reg.predict(df)[0].clip(0, np.inf):0.0f}"

st.markdown(
    f'Proposed price: <span style="font-size:1.5em; margin-top: 10px; background-color: lightgreen; padding: 5px">{ypred} \u00a3</span>',
    unsafe_allow_html=True,
)
